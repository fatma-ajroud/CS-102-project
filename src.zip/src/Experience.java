public class Experience {
	
	// Attributes 
	
	private String type;
	private String title;
	private String establishment;
	private Date start_date; 
	private Date end_date; 
	private String description;
	
	//	 CONSTRUCTOR
	public Experience(String type, String title, String establishment, int s_day, int s_month, int s_year, int e_day, int e_month, int e_year, String description) {
        setType(type);
        setTitle(title);
        setEstablishment(establishment);
        setStart_date(s_day, s_month, s_year);
        setEnd_date(e_day, e_month, e_year);
        setDescription(description);
    }
	
	// getters and setters 
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getEstablishment() {
		return establishment;
	}
	public void setEstablishment(String establishment) {
		this.establishment = establishment;
	}
	
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(int day, int month, int year) {
        this.start_date = new Date(day, month, year); }
	
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(int day, int month, int year ) {
		this.end_date = new Date(day, month, year);
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	} 
	
	
	
}
