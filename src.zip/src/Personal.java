public class Personal {

	
	// ATTRIBUTES
	private String first_name; 
	private String last_name; 
	private Date dob ; //date_of_birth
	private Contacts Contacts; 
	private String address; 
	private String summary;
	
	
	// GETTERS AND SETTERS 
	
	//FN\LN
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	} 
	
	// DOB
		public Date getDob () {
			return dob;
		}
		 public void setDob(int day, int month, int year) {
		        this.dob = new Date(day, month, year);
		    }
		 
	// ADDRESS 
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
	// SUMMARY
		public String getSummary() {
			return summary;
		}
		public void setSummary(String summary) {
			this.summary = summary;
		}
		
		//CONTACTS 
		public Contacts getContacts() {
			return Contacts;
		}
		public void setContacts(String email, String phoneNumber, String socialMedia) {
			this.Contacts = new Contacts(phoneNumber, email, socialMedia); 
		}
		
}
