public class CV {
	
	// ATTRIBUTE 
	
	private Activities Activities ; 
	private Academic Academic ; 
	private Personal Personal; 
	private Achievement Achievement; 
	private Contacts Contacts; 
	private Experience Experience; 
}
