public class Contacts {
	
	// ATTRIBUTES 
    private String phoneNumber;
    private String email;
    private String socialMedia;

    // Constructor
    public Contacts( String phoneNumber, String email, String socialMedia) {
        setPhoneNumber(phoneNumber);
        setEmail(email);
        setSocialMedia(socialMedia);
    }
    
    // GETTERS AND SETTERS 
    
    // PHONE_NUMBER
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	// EMAIL
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	// SOCIAL_MEDIA
	public String getSocialMedia() {
		return socialMedia;
	}

	public void setSocialMedia(String socialMedia) {
		this.socialMedia = socialMedia;
	}
}
